package com.automacent.fwk.enums;

/**
 * This ENUM defines the differenet error codes thrown by the framework
 * 
 * @author sighil.sivadas
 */
public enum ErrorCode {
	INVALID_PARAMETER_VALUE;
}
