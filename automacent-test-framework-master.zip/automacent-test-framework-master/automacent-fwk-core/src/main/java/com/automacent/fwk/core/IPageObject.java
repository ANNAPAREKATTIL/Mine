package com.automacent.fwk.core;

public interface IPageObject {

}
